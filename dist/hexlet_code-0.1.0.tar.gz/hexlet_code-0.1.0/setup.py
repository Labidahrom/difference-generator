# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['argcomplete>=2.0.0,<3.0.0',
 'flake8>=5.0.4,<6.0.0',
 'pytest-cov>=4.0.0,<5.0.0',
 'pytest>=7.1.3,<8.0.0',
 'pyyaml>=6.0,<7.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main',
                     'just = gendiff.scripts.just:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Labidahrom/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/Labidahrom/python-project-50/actions)\n[![Actions Status](https://github.com/Labidahrom/python-project-50/actions/workflows/python-package.yml/badge.svg)](https://github.com/Labidahrom/python-project-50/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/d710eb18965ebe6feb22/maintainability)](https://codeclimate.com/github/Labidahrom/python-project-50/maintainability)\n[![Test Coverage](https://api.codeclimate.com/v1/badges/d710eb18965ebe6feb22/test_coverage)](https://codeclimate.com/github/Labidahrom/python-project-50/test_coverage)\n\n## Usage examples\n### Get diffrence between two json files by cli command\n[![asciicast](https://asciinema.org/a/I5WzbjeyHCh4kIs0PacrSH6xm.svg)](https://asciinema.org/a/I5WzbjeyHCh4kIs0PacrSH6xm)\n### Get diffrence between two yaml files by cli command\n[![asciicast](https://asciinema.org/a/I5WzbjeyHCh4kIs0PacrSH6xm.svg)](https://asciinema.org/a/I5WzbjeyHCh4kIs0PacrSH6xm)\n### Get diffrence between two nested yaml and json files by cli command\n[![asciicast](https://asciinema.org/a/SLVVmi8wkspeH5ksw9AdMLjrj.svg)](https://asciinema.org/a/SLVVmi8wkspeH5ksw9AdMLjrj)\n',
    'author': 'labidahrom',
    'author_email': 'labidahrom@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
