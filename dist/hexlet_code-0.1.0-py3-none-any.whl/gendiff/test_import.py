from scripts.make_gendiff import generate_diff


generate_diff('file1.json', 'file2.json')
