from modules import make_gendiff


make_gendiff.generate_diff('file1.json', 'file2.json')