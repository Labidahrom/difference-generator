import json
from create_diff import make_diff_data
from parser import get_data

file1 = get_data('file1.json')
file2 = get_data('file2.json')
data = make_diff_data(file1, file2)
new_data = json.dumps(data, indent=2)
print(new_data)


